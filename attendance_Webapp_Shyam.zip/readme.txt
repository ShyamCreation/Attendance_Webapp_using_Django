Appname: attendance_Webapp
Work time : 01 Jan 2024 to 15 May 2024
Worked or made by: Yadav Shyam 7048203806 yadavshyam7048@gmail.com
                   Anurag Pandey

admin user: admin
admin password: 123 

Most of paswords is 123 and for user refer admin side.

To run Project:
Must install Python and Django 
Step:1 Creat vitual envirnment virtual environment and activate it.
Step:2 Run this after ensuring virtual environment "pip install -r requirements.txt".
Step:3 Run this in cmd python manage.py runserver

If you face any issue on email.

HAPPY CODING!