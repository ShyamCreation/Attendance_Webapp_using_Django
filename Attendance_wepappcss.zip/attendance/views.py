from django.shortcuts import render

# Create your views here.
from django.shortcuts import render, redirect
from django.contrib.auth import login, authenticate
from django.contrib.auth.decorators import login_required
from .models import *
from .forms import LecturerRegistrationForm, StudentRegistrationForm, LoginForm

def lecturer_register(request):
    if request.method == 'POST':
        form = LecturerRegistrationForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            user = CustomUser.objects.create_user(username=username, email=email, password=password, is_lecturer=True)
            Lecturer.objects.create(user=user)
            return redirect('login')
    else:
        form = LecturerRegistrationForm()
    return render(request, 'lecturer_register.html', {'form': form})

def student_register(request):
    if request.method == 'POST':
        form = StudentRegistrationForm(request.POST, request.FILES)
        if form.is_valid():
            username = form.cleaned_data['username']
            email = form.cleaned_data['email']
            password = form.cleaned_data['password']
            #face_image = request.FILES['face_image']
            profile_picture = form.cleaned_data['profile_picture']
            # Create a new CustomUser instance
            user = CustomUser.objects.create_user(username=username, email=email, password=password, is_student=True)
            
            # Create a new Student instance associated with the user
            student = Student.objects.create(user=user)
            if profile_picture:  # Check if a picture was uploaded
                student.profile_picture = profile_picture
                student.save()
            # Save the encoded face data
            #student.save_encoded_face(face_image)
            
            return redirect('login')
    else:
        form = StudentRegistrationForm()
    return render(request, 'student_register.html', {'form': form})



def user_login(request):
    if request.method == 'POST':
        form = LoginForm(request.POST)
        if form.is_valid():
            username = form.cleaned_data['username']
            password = form.cleaned_data['password']
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                if user.is_lecturer:
                    return redirect('lecturer_dashboard')
                elif user.is_student:
                    return redirect('student_dashboard')
    else:
        form = LoginForm()
    return render(request, 'login.html', {'form': form})

from django.shortcuts import render
from .models import Lecture, Attendance

@login_required
def lecturer_dashboard(request):
    lecturer = request.user.lecturer
    lectures = Lecture.objects.filter(lecturer=lecturer)
    qr_codes = Lecture.objects.filter(lecturer=lecturer)
    attendance_history = Attendance.objects.filter(lecture__in=lectures)
    timetable = Timetable.objects.filter(lecturer=lecturer)
    
    context = {
        'user': request.user,
        'qr_codes': qr_codes,
        'attendance_history': attendance_history,
        'timetable': timetable,
    }
    return render(request, 'lecturer_dashboard.html', context)

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Lecture, Attendance

from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Lecture, Attendance

from .models import Student

@login_required
def student_dashboard(request):
    # Retrieve the logged-in student
    student = request.user.student
    
    # Retrieve the department and semester of the student from the related Student model
    department = student.department
    semester = student.semester
    
    # Fetch attendance records for the student based on department and semester
    attendance_records = Attendance.objects.filter(student=student, lecture__department=department, lecture__semester=semester)
    lectures_conducted = Lecture.objects.filter(
        department=department, semester=semester
    )

    lectures_attended = Attendance.objects.filter(student=student, lecture__department=department, lecture__semester=semester)
    # Fetch total number of lectures conducted for the specific department and semester
    total_lectures_conducted = Lecture.objects.filter(department=department, semester=semester).count()
    
    # Calculate the total number of lectures attended by the student
    total_attended_lectures = attendance_records.count()
    
    # Calculate attendance percentage
    if total_lectures_conducted > 0:
        attendance_percentage = (total_attended_lectures / total_lectures_conducted) * 100
    else:
        attendance_percentage = 0
    
    # Render the student dashboard with attendance information
    context = {
        'department': department,
        'semester': semester,
        'total_attended_lectures': total_attended_lectures,
        'total_lectures_conducted': total_lectures_conducted,
        'attendance_percentage': attendance_percentage,
        'lectures_conducted': lectures_conducted,
        'lectures_attended': lectures_attended
        # Add any other context data you need for the student dashboard
    }
    return render(request, 'student_dashboard.html', context)



import qrcode
from django.shortcuts import render
from django.contrib.auth.decorators import login_required
from .models import Lecture, Timetable, Department, Course, Semester
from io import BytesIO
from django.core.files.base import ContentFile
from PIL import Image
from datetime import datetime, timedelta

@login_required
def generate_qr_code(request):
    lecturer = request.user.lecturer

    if request.method == 'POST':
        time_slot_id = request.POST.get('time_slot')
        department_id = request.POST.get('department')
        course_id = request.POST.get('course')
        semester_id = request.POST.get('semester')
        location = request.POST.get('location')
        longitude = request.POST.get('longitude')
        latitude = request.POST.get('latitude')

        time_slot = Timetable.objects.get(lecturer=lecturer, id=time_slot_id).time_slot
        department = Department.objects.get(id=department_id)
        course = Course.objects.get(id=course_id)
        semester = Semester.objects.get(id=semester_id)

        # Define expiration time (e.g., 30 minutes from now)
        expiration_time = datetime.now() + timedelta(minutes=1)
        expiration_time_str = expiration_time.strftime('%Y-%m-%d %H:%M:%S')

        # Create QR code data including expiration time
        qr_data = f"Lecturer: {request.user.username}, Time Slot: {time_slot}, Department: {department}, Course: {course}, Semester: {semester}, Latitude: {latitude}, Longitude: {longitude}, Expiration Time: {expiration_time_str}"

        # Generate QR code
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_L,
            box_size=6,
            border=4,
        )
        qr.add_data(qr_data)
        qr.make(fit=True)

        # Create an image from the QR code
        img = qr.make_image(fill_color="black", back_color="white")

        # Save the image to a BytesIO buffer
        buffer = BytesIO()
        img.save(buffer, format='PNG')

        # Create a file from the buffer
        image_file = ContentFile(buffer.getvalue())

        # Save image path to Lecture model
        lecture = Lecture.objects.create(
            lecturer=lecturer,
            time_slot=time_slot,
            department=department,
            course=course,
            semester=semester,
            location=location,
            longitude=longitude,
            latitude=latitude,
        )
        lecture.qr_code.save(f'lecture_{request.user.username}_{time_slot}_{course}.png', image_file)
        img_path = lecture.qr_code.url

        return render(request, 'qr_code_generated.html', {'img_path': img_path})

    else:
        timetable = Timetable.objects.filter(lecturer=lecturer)
        time_slot_choices = [(timetable_slot.id, f"{timetable_slot.time_slot.start_time} - {timetable_slot.time_slot.end_time}") for timetable_slot in timetable]
        department_choices = [(department.id, department.name) for department in lecturer.departments.all()]
        course_choices = [(course.id, course.name) for course in lecturer.courses.all()]
        semester_choices = [(semester.id, semester.name) for semester in lecturer.semesters.all()]

        return render(request, 'generate_qr_code.html', {
            'time_slot_choices': time_slot_choices,
            'department_choices': department_choices,
            'course_choices': course_choices,
            'semester_choices': semester_choices,
        })




from django.contrib.auth import logout

def logout_view(request):
    logout(request)
    return redirect('login')

from django.shortcuts import render
from .models import Attendance

def get_attendance_history(request):
    # Fetch attendance history for the logged-in student
    attendance_history = Attendance.objects.filter(student=request.user.student)
    
    context = {
        'attendance_history': attendance_history,
    }
    
    return render(request, 'attendance_history.html', context)


from django.http import JsonResponse
from PIL import Image
import base64
from io import BytesIO
from pyzbar.pyzbar import decode

def upload_qr_code(request):
    if request.method == 'POST':
        # Get the uploaded QR code image from the request
        qr_code_image = request.FILES.get('qr_code_image')

        if qr_code_image:
            # Read the image data from the uploaded file
            image_data = qr_code_image.read()
            print("Image data size:", len(image_data))
            # Decode the image data
            decoded_qr_code_data = decode_qr_code(image_data)

            if decoded_qr_code_data:
                # Extract the QR code data
                qr_code_data = decoded_qr_code_data[0].data.decode('utf-8')
                print("Decoded data:", qr_code_data)
                # Return the QR code data in the response
                return JsonResponse({'qr_code_data': qr_code_data})
            else:
                print("No QR code found in the image")
                return JsonResponse({'error_message': 'No QR code found in the uploaded image'}, status=400)
        else:
            print("No QR code image uploaded")
            return JsonResponse({'error_message': 'No QR code image uploaded'}, status=400)
    else:
        return JsonResponse({'error_message': 'Invalid request method'}, status=405)

def decode_qr_code(image_data):
    try:
        # Open the image using PIL (Python Imaging Library)
        image = Image.open(BytesIO(image_data))
        print("Image opened successfully")
        # Decode the QR code image
        qr_codes = decode(image)

        return qr_codes
    except Exception as e:
        print(f'Error decoding QR code image: {str(e)}')
        return None


from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from .models import Lecture, Attendance
import base64
from pyzbar.pyzbar import decode
from PIL import Image
import io
from datetime import datetime
from django.contrib.auth.decorators import login_required
from django.http import HttpResponseForbidden

@login_required
def scan_qr_code(request):
    if request.method == 'POST':
        latitude = request.POST.get('latitude')
        longitude = request.POST.get('longitude')
        qr_code_data = request.POST.get('qr_code_data')
        print(len(qr_code_data))
        try:
            image_data = base64.b64decode(qr_code_data.split(",")[1])
            image = Image.open(io.BytesIO(image_data))
            qr_codes = decode(image)
        except Exception as e:
            return JsonResponse({'error_message': f'Error decoding QR code image: {str(e)}'}, status=400)

        if qr_codes:
            qr_data = qr_codes[0].data.decode('utf-8').split(', ')
            lecturer_username = qr_data[0].split(': ')[1]
            lecture_department = qr_data[2].split(': ')[1]
            lecture_semester = qr_data[4].split(': ')[1]
            latitude_str = qr_data[5].split(': ')[1]
            longitude_str = qr_data[6].split(': ')[1]
            expiration_time_str = qr_data[7].split(': ')[1]

            latitude_float = float(latitude)
            longitude_float = float(longitude)

            threshold = 0.000089 # 5 Meters
            if (abs(latitude_float - float(latitude_str)) < threshold and
                abs(longitude_float - float(longitude_str)) < threshold):

                # Check if the QR code has expired
                expiration_time = datetime.strptime(expiration_time_str, '%Y-%m-%d %H:%M:%S')
                current_time = datetime.now()
                if current_time <= expiration_time:
                    lecture = Lecture.objects.filter(
                        lecturer__user__username=lecturer_username,
                        department__name=lecture_department,
                        semester__name=lecture_semester
                    ).first()

                    if lecture:
                        # Check if the student belongs to the same department and semester
                        if request.user.is_student and request.user.student.department.name == lecture_department and request.user.student.semester.name == lecture_semester:
                            # Check if attendance already marked for this lecture and student
                            if not Attendance.objects.filter(lecture=lecture, student=request.user.student).exists():
                                # Mark attendance for the corresponding lecture
                                Attendance.objects.create(lecture=lecture, student=request.user.student, attendance_status=True)
                                return JsonResponse({'success_message': 'Attendance marked successfully'}, status=200)
                            else:
                                return JsonResponse({'error_message': 'Attendance already marked for this lecture'}, status=400)
                        else:
                            return JsonResponse({'error_message': 'Student does not belong to this department or semester'}, status=400)
                    else:
                        return JsonResponse({'error_message': 'No matching lecture found'}, status=400)
                else:
                    return JsonResponse({'error_message': 'QR code has expired'}, status=400)
            else:
                return JsonResponse({'error_message': 'Student location does not match QR code location'}, status=400)
        else:
            return JsonResponse({'error_message': 'No QR code detected'}, status=400)
    else:
        return render(request, 'scan_qr_code.html')



# views.py
'''
# views.py
import numpy as np 
import face_recognition
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from .models import Student

@login_required
def access_personal_details(request):
    if request.method == 'POST':
        uploaded_image = request.FILES['image']
        student = request.user.student
        
        if student.encoded_face:
            unknown_image = face_recognition.load_image_file(uploaded_image)
            unknown_face_encoding = face_recognition.face_encodings(unknown_image)
            
            if len(unknown_face_encoding) > 0:
                # Convert the encoded face from the database to a numpy array
                known_face_encoding = np.frombuffer(student.encoded_face, dtype=np.float64)
                
                # Perform the face comparison
                result = face_recognition.compare_faces([known_face_encoding], unknown_face_encoding[0], tolerance=0.6)
                
                if result[0]:
                    return JsonResponse({'success_message': 'Matched successfully'}, status=200)  # Redirect to personal details page if face matches
                else:
                    messages.error(request, "Face doesn't match. Please try again.")
            else:
                messages.error(request, "No face detected in the uploaded image. Please try again.")
        else:
            messages.error(request, "Face data is not available for the current user.")

    return render(request, 'access_personal_details.html')

'''