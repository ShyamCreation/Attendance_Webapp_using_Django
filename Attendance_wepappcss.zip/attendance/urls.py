from django.urls import path
from . import views

urlpatterns = [
    path('lecturer/register/', views.lecturer_register, name='lecturer_register'),
    path('student/register/', views.student_register, name='student_register'),
    path('', views.user_login, name='login'),
    path('lecturer/dashboard/', views.lecturer_dashboard, name='lecturer_dashboard'),
    path('student/dashboard/', views.student_dashboard, name='student_dashboard'),
    path('generate-qr-code/', views.generate_qr_code, name='generate_qr_code'),
    path('scan-qr-code/', views.scan_qr_code, name='scan_qr_code'),
    path('logout/', views.logout_view, name='logout'), 
    path('get-attendance-history/', views.get_attendance_history, name='get_attendance_history'),
    path('upload-qr-code/', views.upload_qr_code, name='upload_qr_code'),
    #path('access-personal-details/', views.access_personal_details, name='access_personal_details'),
]

from django.conf import settings
from django.conf.urls.static import static

# Add this at the end of your urlpatterns
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
