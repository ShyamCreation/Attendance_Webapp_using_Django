from django import forms
from .models import *

class LecturerRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'password')

class StudentRegistrationForm(forms.ModelForm):
    password = forms.CharField(widget=forms.PasswordInput())
    profile_picture = forms.ImageField(label='Profile Picture', required=False)
    #face_image = forms.ImageField(label='Face Image')


    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'password', 'profile_picture')

class LoginForm(forms.Form):
    username = forms.CharField(label='Enrollment_Id / Username')
    password = forms.CharField(label='Password', widget=forms.PasswordInput())

''''
from django import forms

class LectureForm(forms.Form):
    module = forms.CharField(max_length=255)
    start_time = forms.DateTimeField()
    end_time = forms.DateTimeField()
    location_coordinates = forms.CharField(max_length=255, widget=forms.HiddenInput())
    radius = forms.DecimalField(max_digits=10, decimal_places=6, required=False)

from django import forms

class QRCodeGenerationForm(forms.Form):
    module = forms.CharField(max_length=255, label='Module Name')
    start_time = forms.DateTimeField(label='Start Time', input_formats=['%Y-%m-%dT%H:%M'])
    end_time = forms.DateTimeField(label='End Time', input_formats=['%Y-%m-%dT%H:%M'])
    longitude = forms.FloatField(widget=forms.HiddenInput())
    latitude = forms.FloatField(widget=forms.HiddenInput())
    #course = forms.ModelChoiceField(queryset=Course.objects.all())


from django import forms
from .models import Lecture, Timetable

class GenerateQRCodeForm(forms.ModelForm):
    longitude = forms.DecimalField(max_digits=9, decimal_places=6)
    latitude = forms.DecimalField(max_digits=9, decimal_places=6)

    class Meta:
        model = Lecture
        fields = ['time_slot', 'department', 'course', 'semester', 'location', 'longitude', 'latitude']

    def __init__(self, lecturer, *args, **kwargs):
        super(GenerateQRCodeForm, self).__init__(*args, **kwargs)
        # Get the lecturer's timetable and create choices for time_slot based on that
        timetable = Timetable.objects.filter(lecturer=lecturer)
        time_slot_choices = [(timetable_slot.time_slot.id, f"{timetable_slot.time_slot.start_time} - {timetable_slot.time_slot.end_time}") for timetable_slot in timetable]
        self.fields['time_slot'] = forms.ChoiceField(choices=time_slot_choices)

        # Set placeholders
        self.fields['location'].widget.attrs['placeholder'] = 'Enter Location'
        self.fields['longitude'].widget.attrs['placeholder'] = 'Enter Longitude'
        self.fields['latitude'].widget.attrs['placeholder'] = 'Enter Latitude'
'''