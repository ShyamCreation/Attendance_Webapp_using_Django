from django.http import HttpResponse

from django.shortcuts import render

def base(request):
      # Example context data
    return render(request, 'base.html')  # Render child template
